package point_of_interest_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PointOfInterestServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
